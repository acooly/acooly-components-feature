var express = require('express');
var router = express.Router();
const Core = require('@alicloud/pop-core');

const accessKeyId = 'E3S6cuJ1tOofrcbXVYbkJQ=='
const accessKeySecret = '4LLmHY2C84MzF8CkZQB2IQ=='
const endpoint = 'http://sms.anycmp.com:8080'
const apiVersion = '2017-05-25'

/* GET home page. */
router.get('/', function (req, res, next) {
	res.render('index', {
		title: 'Express'
	});
});

router.get('/send', function (req, res, next) {
	var client = new Core({
		accessKeyId: accessKeyId,
		accessKeySecret: accessKeySecret,
		endpoint: `${endpoint}/sms/send`,
		apiVersion: apiVersion
	});
	var params = {
		"phoneNumbers": "18502665927",
		"regionId": "ydy",
		"signName": "云顶云",
		"templateCode": "SMS_64685056",
		"templateParam": "{\"content\":\"测试\"}"
	}
	var requestOption = {
		method: 'GET'
	};
	request(res, client, params, requestOption)
});

router.get('/batch/send', function (req, res, next) {
	var client = new Core({
		accessKeyId: accessKeyId,
		accessKeySecret: accessKeySecret,
		endpoint: `${endpoint}/sms/batch/send`,
		apiVersion: apiVersion
	});
	var params = {
		"phoneNumberJson": "[\"15802210707\",\"15513485226\"]",
		"regionId": "ydy",
		"signNameJson": "[\"云顶云\",\"云顶云\"]",
		"templateCode": "SMS_136860720",
		"templateParamJson": "[{\"userName\":\"任天琦\",\"product\":\"ECS\",\"instanceId\":\"i-abc\",\"dateTime\":\"16:39\",\"metricName\":\"cpu\",\"expression\":\"测试\"},{\"userName\":\"任天琦\",\"product\":\"ECS\",\"instanceId\":\"i-abc\",\"dateTime\":\"16:39\",\"metricName\":\"cpu\",\"expression\":\"测试\"}]"
	}
	var requestOption = {
		method: 'GET'
	};
	request(res, client, params, requestOption)
});

function request (res, client, params, requestOption) {
	client.request('/', params, requestOption)
		.then((result) => {
			console.log(result);
			res.json(result)
		}, (ex) => {
			console.log(ex);
			res.json(ex)
		})
}

module.exports = router;